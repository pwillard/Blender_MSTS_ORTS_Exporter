Compatibility build using legacy module name 'io_export_mstsexporter'.
